package ca.mcgill.ecse223.resto.view;

import javax.swing.JFrame;

public class ToggleUse extends JFrame{

	
	public ToggleUse() {
		initComponents();
	}
	
	
	/**
	 * Create the frame
	 */
	public void initComponents() {
		
	}
	
	
}
